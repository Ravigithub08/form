const radio_1 = document.querySelector('.ra-1');
const radio_2 = document.querySelector('.ra-2');
const c_box=document.querySelectorAll('.check');
const btn=document.querySelector('.btn');


radio_1.addEventListener("click",function(){

    radio_2.checked=false;
    radio_1.checked=true;
    

})
radio_2.addEventListener("click",function(){

    radio_1.checked=false;
    radio_2.checked=true;
    
})

function check(){
    let check_box=false;
    let check_rad=false;
    for(i=0;i<c_box.length;i++){
        if(c_box[i].checked){
        check_box=true;  
        }          
     }
     if (radio_1.checked || radio_2.checked) {
        check_rad=true;
        
     }
     
     if(check_box && check_rad){

        console.log(check_box,check_rad);
        btn.disabled=false;
     }


     

}
c_box.forEach((ele)=>{
ele.addEventListener("click",check)
})
radio_1.addEventListener("click",check)
radio_2.addEventListener("click",check)


