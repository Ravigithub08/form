

<?php


        if(!empty($_POST['send'])){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $add=$_POST['add'];
            $box=$_POST['ch'];
            $r_b=$_POST['radio'];
        
        $to='gravikumarg99@gmail.com';
        $mailheaders="Name:" . $name . "\r\n E-mail:" . $email . "\r\n Address:" . $add . "\r\n Iam a" . $r_b . "\r\n I know about your company by" . $box;
        if(mail($to,$name,$mailheaders)){
            echo "success";
        }
    }
    ?>